fun main() {
    val readableNumber = 1_000_000
    print(readableNumber)
}