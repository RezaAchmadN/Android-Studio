fun main() {
    val valueA: Int = 10
    val valueB = 20
    print(valueA + valueB)
}