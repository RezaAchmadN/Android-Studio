fun main() {
    var counter = 8
    while (counter <= 7){
        println("Hello, World!")
        counter++
    }
    var value = 'A'
    do {
        print(value)
    } while (value <= 'Z')
}