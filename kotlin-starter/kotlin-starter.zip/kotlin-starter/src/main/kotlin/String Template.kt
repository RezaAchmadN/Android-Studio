fun main() {
    val hour = 7
    print("Office ${if (hour > 7) "already close" else "is open"}")
}