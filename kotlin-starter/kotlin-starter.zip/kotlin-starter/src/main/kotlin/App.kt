fun main() {
    println("Hello Kotlin!")
}