fun main() {
    val intArray = intArrayOf(1, 3, 5, 7)
    intArray[2] = 11

    print(intArray[2])
}